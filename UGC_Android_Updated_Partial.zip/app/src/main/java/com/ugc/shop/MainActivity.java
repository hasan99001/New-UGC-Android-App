package com.ugc.shop;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.content.ContentValues;
import android.database.Cursor;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import android.content.SharedPreferences;
import android.util.Base64;

public class MainActivity extends Activity {
    private WebView web;
    private BluetoothSocket socket;
    private BluetoothDevice printer;
    private String pendingCloudBackup;
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new UGCBridge(), "AndroidUGC");
        web.loadUrl("file:///android_asset/index.html");
    }

    private boolean bluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 71);
            return false;
        }
        return true;
    }

    private class UGCBridge {
        private SharedPreferences authPrefs() { return getSharedPreferences("ugc_admin_auth", MODE_PRIVATE); }
        @JavascriptInterface public boolean hasAdminPassword() {
            return authPrefs().contains("password_hash") && authPrefs().contains("password_salt");
        }
        private byte[] derivePassword(String password, byte[] salt) throws Exception {
            KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 120000, 256);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).getEncoded();
        }
        @JavascriptInterface public boolean setAdminPassword(String password) {
            if (password == null || password.length() < 6) return false;
            try {
                byte[] salt = new byte[16]; new SecureRandom().nextBytes(salt);
                byte[] hash = derivePassword(password, salt);
                authPrefs().edit().putString("password_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putString("password_hash", Base64.encodeToString(hash, Base64.NO_WRAP))
                    .putInt("failed_attempts", 0).putLong("locked_until", 0).apply();
                return true;
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public synchronized String verifyAdminPassword(String password) {
            SharedPreferences prefs = authPrefs();
            long lockedUntil = prefs.getLong("locked_until", 0);
            if (System.currentTimeMillis() < lockedUntil) return "LOCKED";
            try {
                byte[] salt = Base64.decode(prefs.getString("password_salt", ""), Base64.NO_WRAP);
                byte[] expected = Base64.decode(prefs.getString("password_hash", ""), Base64.NO_WRAP);
                byte[] actual = derivePassword(password == null ? "" : password, salt);
                if (MessageDigest.isEqual(expected, actual)) {
                    prefs.edit().putInt("failed_attempts", 0).putLong("locked_until", 0).apply();
                    return "OK";
                }
            } catch (Exception ignored) { }
            int attempts = prefs.getInt("failed_attempts", 0) + 1;
            SharedPreferences.Editor edit = prefs.edit().putInt("failed_attempts", attempts);
            if (attempts >= 5) edit.putLong("locked_until", System.currentTimeMillis() + 5 * 60 * 1000L).putInt("failed_attempts", 0);
            edit.apply();
            return attempts >= 5 ? "LOCKED" : "INVALID";
        }
        @JavascriptInterface public void saveProductStock(String json) {
            try { saveDownloadFile("UGC/Product_Stock", "product_stock.json", json); }
            catch (Exception e) { runOnUiThread(() -> toast("পণ্য ও স্টকের ফাইল সংরক্ষণ হয়নি")); }
        }
        @JavascriptInterface public void saveLocalBackup(String json) {
            try { saveDownloadFile("UGC/Backups", "UGC-backup-" + System.currentTimeMillis() + ".json", json);
                runOnUiThread(() -> toast("ফোনে ব্যাকআপ সংরক্ষণ হয়েছে: Download/UGC/Backups")); }
            catch (Exception e) { runOnUiThread(() -> toast("ফোনে ব্যাকআপ সংরক্ষণ করা যায়নি")); }
        }
        @JavascriptInterface public void saveCloudBackup(String json) {
            runOnUiThread(() -> {
                try {
                    pendingCloudBackup = json;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, "UGC-cloud-backup-" + System.currentTimeMillis() + ".json");
                    startActivityForResult(intent, 81);
                } catch (Exception e) { toast("Google Drive বা Files অ্যাপ পাওয়া যায়নি"); }
            });
        }
        private void saveDownloadFile(String relativeFolder, String filename, String content) throws Exception {
            if (Build.VERSION.SDK_INT >= 29) {
                String relativePath = Environment.DIRECTORY_DOWNLOADS + "/" + relativeFolder;
                String[] projection = { MediaStore.Downloads._ID };
                String selection = MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?";
                try (Cursor cursor = getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, new String[]{filename, relativePath}, null)) {
                    if (cursor != null) while (cursor.moveToNext()) {
                        long oldId = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID));
                        Uri oldUri = Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, String.valueOf(oldId));
                        getContentResolver().delete(oldUri, null, null);
                    }
                }
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                values.put(MediaStore.Downloads.RELATIVE_PATH, relativePath);
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Could not create file");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Could not open file");
                    out.write(content.getBytes(StandardCharsets.UTF_8));
                }
                ContentValues done = new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            } else {
                File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), relativeFolder);
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create folder");
                try (FileOutputStream out = new FileOutputStream(new File(dir, filename))) {
                    out.write(content.getBytes(StandardCharsets.UTF_8));
                }
            }
        }
        @JavascriptInterface public void selectPrinter() { runOnUiThread(() -> choosePrinter()); }
        @JavascriptInterface public void testPrint(String paper) { runOnUiThread(() -> printText("UNIQUE GADGET COLLECTION\nPRINTER TEST\nPaper: " + paper + "\nThank you\n\n")); }
        @JavascriptInterface public void printEscPos(String json) {
            try {
                JSONObject data = new JSONObject(json);
                JSONObject memo = data.optJSONObject("memo");
                if (memo == null) return;
                String text = "UNIQUE GADGET COLLECTION\nSALES MEMO\n" +
                    "Memo: " + memo.optString("no") + "\n" +
                    "Date: " + memo.optString("date") + "\n" +
                    "Customer: " + memo.optString("customer") + "\n" +
                    "Phone: " + memo.optString("phone") + "\n" +
                    "Product: " + memo.optString("product") + " x " + memo.optInt("qty") + "\n" +
                    "Total: Tk " + memo.optString("total") + "\n" +
                    "Paid: Tk " + memo.optString("paid") + "\n" +
                    "Due: Tk " + memo.optString("due") + "\n\n\n";
                runOnUiThread(() -> printText(text));
            } catch (Exception e) { runOnUiThread(() -> toast("মেমো প্রস্তুত করা যায়নি")); }
        }
    }

    private void choosePrinter() {
        if (!bluetoothPermission()) return;
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) { toast("এই ফোনে Bluetooth নেই"); return; }
            if (!adapter.isEnabled()) { toast("আগে ফোনের Bluetooth চালু করুন"); return; }
            Set<BluetoothDevice> paired = adapter.getBondedDevices();
            ArrayList<BluetoothDevice> devices = new ArrayList<>(paired);
            if (devices.isEmpty()) { toast("আগে Settings থেকে প্রিন্টার Pair করুন"); return; }
            String[] names = new String[devices.size()];
            for (int i=0;i<devices.size();i++) names[i] = devices.get(i).getName() + "  (" + devices.get(i).getAddress() + ")";
            new AlertDialog.Builder(this).setTitle("Paired Bluetooth Printer").setItems(names, (d, which) -> connect(devices.get(which))).setNegativeButton("বাতিল", null).show();
        } catch (SecurityException e) { toast("Bluetooth অনুমতি প্রয়োজন"); }
    }

    private void connect(BluetoothDevice device) {
        new Thread(() -> {
            try {
                if (socket != null) try { socket.close(); } catch (Exception ignored) {}
                socket = device.createRfcommSocketToServiceRecord(SPP);
                socket.connect(); printer = device;
                runOnUiThread(() -> toast("প্রিন্টার সংযুক্ত: " + device.getName()));
            } catch (Exception e) {
                socket = null; printer = null;
                runOnUiThread(() -> toast("সংযোগ হয়নি। Pairing ও printer model পরীক্ষা করুন।"));
            }
        }).start();
    }

    private void printText(String text) {
        if (!bluetoothPermission()) return;
        new Thread(() -> {
            try {
                if (socket == null || !socket.isConnected()) throw new Exception("not connected");
                OutputStream out = socket.getOutputStream();
                out.write(new byte[]{0x1B, 0x40}); // ESC/POS initialize
                out.write(text.getBytes(StandardCharsets.UTF_8));
                out.write(new byte[]{0x0A,0x0A,0x0A,0x1D,0x56,0x00}); // feed + cut (if supported)
                out.flush();
                runOnUiThread(() -> toast("প্রিন্ট পাঠানো হয়েছে"));
            } catch (Exception e) { runOnUiThread(() -> toast("প্রিন্টার সংযুক্ত নেই। আগে প্রিন্টার Pair ও Connect করুন।")); }
        }).start();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 81) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingCloudBackup != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("No output stream");
                    out.write(pendingCloudBackup.getBytes(StandardCharsets.UTF_8));
                    toast("ক্লাউড ব্যাকআপ সংরক্ষণ হয়েছে");
                } catch (Exception e) { toast("ক্লাউডে ব্যাকআপ সংরক্ষণ হয়নি"); }
            } else { toast("ক্লাউড ব্যাকআপ বাতিল করা হয়েছে"); }
            pendingCloudBackup = null;
        }
    }

    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
